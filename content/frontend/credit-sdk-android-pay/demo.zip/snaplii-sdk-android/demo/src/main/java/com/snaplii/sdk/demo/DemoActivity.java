package com.snaplii.sdk.demo;

import android.Manifest;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.snaplii.sdk.Constants;
import com.snaplii.sdk.SnapliiSdk;
import com.snaplii.sdk.callback.ILoginCallback;
import com.snaplii.sdk.callback.OTPCallback;
import com.snaplii.sdk.callback.PayResultCallback;
import com.snaplii.sdk.callback.RetOTPCallback;

import org.json.JSONObject;

public class DemoActivity extends AppCompatActivity {

    public static final String TAG = DemoActivity.class.getSimpleName();
    private RetOTPCallback mRetOTPCallback;

    public static String sAppId = "";
    public static String sKey = "";

    private TextView mLoginTv;

    private final String[] permissions = new String[]{
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initView();

        requestPermissions();
    }

    private void initView() {
        setContentView(R.layout.activity_main);

        mLoginTv = findViewById(R.id.tv_login_data);
        findViewById(R.id.sdk_version).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(DemoActivity.this, SnapliiSdk.getVersion(), Toast.LENGTH_LONG).show();
            }
        });

        findViewById(R.id.tv_init).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                init();
                Toast.makeText(DemoActivity.this, "init called", Toast.LENGTH_LONG).show();
            }
        });

        findViewById(R.id.tv_login).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SnapliiSdk.login(DemoActivity.this, new ILoginCallback() {
                    @Override
                    public void onSuccess() {
                        //Toast.makeText(DemoActivity.this, "login success", Toast.LENGTH_LONG).show();
                        Log.e(TAG, "login success");
                    }

                    @Override
                    public void onCancel() {
                        //Toast.makeText(DemoActivity.this, "login cancel", Toast.LENGTH_LONG).show();
                        Log.e(TAG, "login cancel");
                    }
                });
            }
        });

        findViewById(R.id.tv_pay).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pay();
            }
        });
    }

    private void init() {
        EditText editText = findViewById(R.id.ed_pt);
        String pt = editText.getText().toString();
        if (TextUtils.isEmpty(pt)) {
            Toast.makeText(DemoActivity.this, "请输入pt", Toast.LENGTH_LONG).show();
            return;
        }

        SnapliiSdk.setDebug(true);
        SnapliiSdk.initSdk(getApplication(), sAppId, pt, Constants.LANGUAGE_EN, "", new OTPCallback() {

            @Override
            public void getOtp(RetOTPCallback callback) {
                mRetOTPCallback = callback;
                new Thread(() -> reqOtp2()).start();
            }
        });
    }

    private void pay() {
        if (TextUtils.isEmpty(SnapliiSdk.sPt)) {
            Toast.makeText(DemoActivity.this, "请先初始化sdk", Toast.LENGTH_LONG).show();
            return;
        }
        JSONObject orderObject = new JSONObject();
        EditText amt = findViewById(R.id.ed_amt);
        String inputAmt = amt.getText().toString();
        try {
            long ts = System.currentTimeMillis();
            String randomString = String.valueOf(ts);
            orderObject.put("outterOrderNo", randomString);
            orderObject.put("orderAmount", inputAmt);
            orderObject.put("personalToken", SnapliiSdk.sPt);
            orderObject.put("sign", getOrderSign(orderObject.toString()));
        } catch (Exception e) {
            e.printStackTrace();
        }

        SnapliiSdk.payment(DemoActivity.this, orderObject.toString(), new PayResultCallback() {
            @Override
            public void onSuccess() {
                Toast.makeText(DemoActivity.this, "支付成功", Toast.LENGTH_LONG).show();
            }

            @Override
            public void onError(String errorCode, String errorMsg) {
                Toast.makeText(DemoActivity.this, "支付失败", Toast.LENGTH_LONG).show();
            }
        });
    }

    private void reqOtp2() {

    }

    private void requestPermissions() {
        ActivityCompat.requestPermissions(this, permissions, 100);
    }

    private String getOrderSign(String orderJson) {
        return "";
    }

    @Override
    protected void onResume() {
        super.onResume();

        mLoginTv.setText("pt = " + SnapliiSdk.sPt);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_settings) {
            ((EditText) findViewById(R.id.ed_pt)).setText("");
            SnapliiSdk.logout();
            return true;
        }
        if (item.getItemId() == R.id.action_lang) {
            if (TextUtils.equals(SnapliiSdk.sLanguage, Constants.LANGUAGE_EN))
                SnapliiSdk.setLanguage(Constants.LANGUAGE_ZH);
            else
                SnapliiSdk.setLanguage(Constants.LANGUAGE_EN);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}