package com.snaplii.sdk.demo;

import android.app.Application;

public class AppApplication extends Application {

    public static final String TAG = AppApplication.class.getSimpleName();

    @Override
    public void onCreate() {
        super.onCreate();
    }
}
