package com.snaplii.sdk.demo;

import android.app.Application;

import com.snaplii.sdk.Constants;
import com.snaplii.sdk.SnapliiSdk;
import com.snaplii.sdk.callback.OTPCallback;
import com.snaplii.sdk.callback.RetOTPCallback;

public class AppApplication extends Application {

    public static final String TAG = AppApplication.class.getSimpleName();

    private RetOTPCallback mRetOTPCallback;

    @Override
    public void onCreate() {
        super.onCreate();
        //TODO: set appId and pt
        SnapliiSdk.initSdk(this, "", "", Constants.LANGUAGE_EN, "", new OTPCallback() {

            @Override
            public void getOtp(RetOTPCallback callback) {
                mRetOTPCallback = callback;
                new Thread(() -> reqOtp()).start();
            }
        });

    }


    private void reqOtp() {
        //TODO: 获取otp
    }

}
