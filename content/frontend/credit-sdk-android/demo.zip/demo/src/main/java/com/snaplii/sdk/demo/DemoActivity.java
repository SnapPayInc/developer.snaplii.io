package com.snaplii.sdk.demo;

import android.Manifest;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.snaplii.sdk.Constants;
import com.snaplii.sdk.SnapliiSdk;
import com.snaplii.sdk.callback.ICCallback;
import com.snaplii.sdk.callback.ICreditCallback;
import com.snaplii.sdk.callback.PayResultCallback;

import org.json.JSONObject;

import java.util.UUID;

public class DemoActivity extends AppCompatActivity {

    public static final String TAG = DemoActivity.class.getSimpleName();

    private final String[] permissions = new String[]{
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
    };

    private TextView mLoginTv;

    private boolean mHasCredit = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initView();

        requestPermissions();
    }

    private void initView() {
        setContentView(R.layout.activity_main);

        mLoginTv = findViewById(R.id.tv_login_data);

        findViewById(R.id.tv_banner).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SnapliiSdk.initSnapliiCredit(DemoActivity.this, new ICCallback() {
                    @Override
                    public void onSuccess() {

                    }

                    @Override
                    public void onError(String errorCode, String errorMsg) {

                    }
                });
            }
        });

        findViewById(R.id.tv_pay).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!mHasCredit) {
                    Toast.makeText(DemoActivity.this, "请先开通信用付", Toast.LENGTH_SHORT).show();
                    return;
                }
                JSONObject orderObject = new JSONObject();
                try {
                    //TODO: 请使用自己的订单号，金额，pt，签名
                    orderObject.put("outterOrderNo", "");
                    orderObject.put("orderAmount", "0.01");
                    orderObject.put("personalToken", "");
                    orderObject.put("sign", "xxxxxxxxxxxxxxx");
                } catch (Exception e) {
                    e.printStackTrace();
                }

                SnapliiSdk.payment(DemoActivity.this, orderObject.toString(), new PayResultCallback() {
                    @Override
                    public void onSuccess() {

                    }

                    @Override
                    public void onError(String errorCode, String errorMsg) {

                    }
                });
            }
        });

        findViewById(R.id.sdk_version).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(DemoActivity.this, SnapliiSdk.getVersion(), Toast.LENGTH_LONG).show();
            }
        });
    }

    private void requestPermissions() {
        ActivityCompat.requestPermissions(this, permissions, 100);
    }

    private void reqHasSnapliiCredit() {
        SnapliiSdk.hasSnapliiCredit(new ICreditCallback() {
            @Override
            public void onSuccess(boolean hasCredit) {
                mHasCredit = hasCredit;
                if (hasCredit) {
                    findViewById(R.id.tv_banner).setVisibility(View.GONE);
                    findViewById(R.id.tv_pay).setVisibility(View.VISIBLE);
                } else {
                    findViewById(R.id.tv_banner).setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onError(String code, String msg) {
                findViewById(R.id.tv_banner).setVisibility(View.VISIBLE);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();

        reqHasSnapliiCredit();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_settings) {

            return true;
        }
        if (item.getItemId() == R.id.action_lang) {
            if (TextUtils.equals(SnapliiSdk.sLanguage, Constants.LANGUAGE_EN))
                SnapliiSdk.setLanguage(Constants.LANGUAGE_ZH);
            else
                SnapliiSdk.setLanguage(Constants.LANGUAGE_EN);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}