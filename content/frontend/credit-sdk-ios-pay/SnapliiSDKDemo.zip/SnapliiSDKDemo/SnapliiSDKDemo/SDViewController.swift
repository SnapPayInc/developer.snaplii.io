//
//  SDViewController.swift
//  SnapliiSDKDemo
//
//  Created by Tony on 2023-07-19.
//

import UIKit
import SnapliiSDK
import AFNetworking
import SnapKit

// fantuan sandbox
let APP_ID = ""
let kSignKey = ""

class SDViewController: UIViewController {

    @IBOutlet weak var ptLabel: UILabel!
    @IBOutlet weak var amountLabel: UILabel!
    @IBOutlet weak var signLabel: UILabel!
    @IBOutlet weak var outterOrderNoLabel: UILabel!
    
    @IBOutlet weak var resultLabel: UILabel!
    @IBOutlet weak var errorLabel: UILabel!
    
    @IBOutlet weak var languageLabel: UILabel!
    
    @IBAction func onLanguageSwitch(_ sender: UISwitch) {
        lang = sender.isOn ? "en" : "zh"
    }
    
    @IBOutlet weak var containerView: UIScrollView!
    
    @IBOutlet weak var ptTextField: UITextField!
    
    @IBOutlet weak var amountTextField: UITextField!
    
    var pt = "" {
        didSet {
            ptLabel.text = "PT: \(pt)"
        }
    }
    
    var amount = "" {
        didSet {
            amountLabel.text = "Amount: \(amount)"
        }
    }
    
    var sign = "" {
        didSet {
            signLabel.text = "Sign: \(sign)"
        }
    }
    
    var outterOrderNo = "" {
        didSet {
            outterOrderNoLabel.text = "OutterOrderNo: \(outterOrderNo)"
        }
    }
    
    // "zh" or "en"
    var lang: String = "en" {
        didSet {
            languageLabel.text = lang
            SnapliiSDKManager.defaultService().setLanguage(lang)
        }
    }
    
    var result: String = "" {
        didSet {
            resultLabel.text = "Result: \(result)"
        }
    }
    
    var error: String = "" {
        didSet {
            errorLabel.text = "Error: \(error)"
        }
    }
    
    @IBOutlet weak var topStack: UIStackView!
    @IBOutlet weak var bottomStack: UIStackView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = "SDKDemo"
    
        lang = "en"
        
        containerView.delegate = self
        containerView.contentInsetAdjustmentBehavior = .never
        containerView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
        containerView.contentSize = CGSize(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height * 1.5)
        
        topStack.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalToSuperview().offset(80)
            make.width.equalToSuperview()
        }
        
        bottomStack.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(topStack.snp.bottom).offset(30)
            make.width.equalToSuperview()
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(false, animated: true)
    }

    @IBAction func initButtonDidClick(_ sender: Any) {
        pt = (ptTextField.text ?? "").isEmpty ? "12345678" : ptTextField.text!
        amount = (amountTextField.text ?? "").isEmpty ? "123.34" : amountTextField.text!
        
        endEdit()
        
        SnapliiSDKManager.defaultService().initAppId(APP_ID, language: lang, personalToken: pt, customerData: "") { [weak self] responseCallback in
            guard let strongSelf = self else {
                return
            }
            strongSelf.getOtp { result, error in
                if let opt = result {
                    responseCallback(opt)
                } else if let error = error {
                    dump(error)
                }
            }
        }
    }
    
    @IBAction func hasSnapliiCredit(_ sender: Any) {
        endEdit()
        SnapliiSDKManager.defaultService().hasSnapliiCredit { [weak self] success, message in
            guard let strongSelf = self else { return }
            strongSelf.result = message ?? ""
        }
    }
    
    @IBAction func getToApplySnapliiCredit(_ sender: Any) {
        endEdit()
        SnapliiSDKManager.defaultService().initSnapliiCredit { [weak self] success, message in
            guard let strongSelf = self else { return }
            strongSelf.resultLabel.text = message ?? ""
        }
    }
    
    @IBAction func getOrderNumber(_ sender: Any) {
        resetResultUI()
    }
    
    @IBAction func payButtonDidClick(_ sender: Any) {
        endEdit()
        resetResultUI()
        
        let url = ""
        
        // get sign and outterOrderNo from backend server

        let sign = ""
        let outterOrderNo = ""
        
        self.goToPayment(sign, outterOrderNo)
    }
    
    @IBAction func hasLogin(_ sender: Any) {
        endEdit()
        let hasLogin = SnapliiSDKManager.defaultService().hasLogin()
        self.resultLabel.text = hasLogin ? "has login" : "not login"
    }
    
    @IBAction func login(_ sender: Any) {
        endEdit()
        SnapliiSDKManager.defaultService().login(self) { success, message in

        }
    }
    
    @IBAction func logout(_ sender: Any) {
        SnapliiSDKManager.defaultService().logout()
    }
    
    
    func resetResultUI() {
        error = ""
        result = ""
    }
    
    func goToPayment(_ sign: String, _ outterOrderNo: String) {
        SnapliiSDKManager.defaultService().payment(sign, orderAmount: amount, outterOrderNo: outterOrderNo, viewController: self) { [weak self] success, message in
            guard let strongSelf = self else { return }
            dump("Payment result: \(message ?? "success")")
            strongSelf.result = message ?? ""
        }
    }
    
    func getOtp(callback: @escaping (_ result: String?, _ error: String?) -> Void) {
        let url = ""
        
        // get otp from backend server
    }
    
    lazy var networkManager: AFHTTPSessionManager = {
        let manager = AFHTTPSessionManager(sessionConfiguration: URLSessionConfiguration.default)
        manager.requestSerializer = AFJSONRequestSerializer()
        manager.requestSerializer.setValue("application/json", forHTTPHeaderField: "Content-Type")
        manager.responseSerializer = AFHTTPResponseSerializer()
        manager.responseSerializer.acceptableContentTypes = [
            "application/json", "text/html", "text/json", "text/plain", "text/javascript", "text/xml", "image/*"
        ]
        return manager
    }()
}

extension SDViewController: UIScrollViewDelegate {
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        ptTextField.endEditing(true)
        amountTextField.endEditing(true)
    }
    
    func endEdit() {
        ptTextField.endEditing(true)
        amountTextField.endEditing(true)
    }
}
