//
//  SDInfoViewController.swift
//  SnapliiSDKDemo
//
//  Created by Tony on 2023-07-21.
//  Copyright © 2023 Snaplii. All rights reserved.
//

import UIKit

class SDInfoViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
}
