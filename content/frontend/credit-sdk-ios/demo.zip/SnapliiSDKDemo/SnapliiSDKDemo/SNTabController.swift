//
//  SNTabController.swift
//  SnapliiSDKDemo
//
//  Created by Tony on 2023-07-21.
//  Copyright © 2023 Snaplii. All rights reserved.
//

import UIKit

class SNTabController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        if #available(iOS 15.0, *) {
            let appearnce = UITabBarAppearance()
            tabBar.standardAppearance = appearnce
            tabBar.scrollEdgeAppearance = appearnce
        }
        
        tabBar.isTranslucent = false

        var tabItems: [UIViewController] = []
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let vc_1 = storyboard.instantiateInitialViewController() {
            let nav = UINavigationController(rootViewController: vc_1)
            nav.tabBarItem = UITabBarItem(title: "SDKDemo", image: UIImage(named: "homeOff"), selectedImage: UIImage(named: "homeOn"))
            tabItems.append(nav)
        }
        
        do {
            let vc_2 = storyboard.instantiateViewController(withIdentifier: "SDInfoViewController")
            let nav = UINavigationController(rootViewController: vc_2)
            nav.tabBarItem = UITabBarItem(title: "Tab2", image: UIImage(named: "cardOff"), selectedImage: UIImage(named: "cardOn"))
            tabItems.append(nav)
        }
        
        viewControllers = tabItems
    }
}
