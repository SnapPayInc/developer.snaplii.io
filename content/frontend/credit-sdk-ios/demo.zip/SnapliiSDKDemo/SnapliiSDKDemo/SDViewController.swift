//
//  SDViewController.swift
//  SnapliiSDKDemo
//
//  Created by Tony on 2023-07-19.
//

import UIKit
import SnapliiSDK
import AFNetworking
import SnapKit

let APP_ID = ""
let kSignKey = ""

class SDViewController: UIViewController {

    @IBOutlet weak var ptLabel: UILabel!
    @IBOutlet weak var amountLabel: UILabel!
    @IBOutlet weak var signLabel: UILabel!
    @IBOutlet weak var outterOrderNoLabel: UILabel!
    
    @IBOutlet weak var resultLabel: UILabel!
    @IBOutlet weak var errorLabel: UILabel!
    
    @IBOutlet weak var languageLabel: UILabel!
    
    @IBAction func onLanguageSwitch(_ sender: UISwitch) {
        lang = sender.isOn ? "en" : "zh"
    }
    
    @IBOutlet weak var containerView: UIScrollView!
    
    @IBOutlet weak var ptTextField: UITextField!
    
    @IBOutlet weak var amountTextField: UITextField!
    
    var pt = "" {
        didSet {
            ptLabel.text = "PT: \(pt)"
        }
    }
    
    var amount = "" {
        didSet {
            amountLabel.text = "Amount: \(amount)"
        }
    }
    
    var sign = "" {
        didSet {
            signLabel.text = "Sign: \(sign)"
        }
    }
    
    var outterOrderNo = "" {
        didSet {
            outterOrderNoLabel.text = "OutterOrderNo: \(outterOrderNo)"
        }
    }
    
    // "zh" or "en"
    var lang: String = "en" {
        didSet {
            languageLabel.text = lang
            SnapliiSDKManager.defaultService().setLanguage(lang)
        }
    }
    
    var result: String = "" {
        didSet {
            resultLabel.text = "Result: \(result)"
        }
    }
    
    var error: String = "" {
        didSet {
            errorLabel.text = "Error: \(error)"
        }
    }
    
    @IBOutlet weak var topStack: UIStackView!
    @IBOutlet weak var bottomStack: UIStackView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = "SDKDemo"
    
        lang = "en"
        
        containerView.delegate = self
        containerView.contentInsetAdjustmentBehavior = .never
        containerView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
        containerView.contentSize = CGSize(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height * 1.5)
        
        topStack.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalToSuperview().offset(80)
            make.width.equalToSuperview()
        }
        
        bottomStack.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(topStack.snp.bottom).offset(30)
            make.width.equalToSuperview()
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(false, animated: true)
    }

    @IBAction func initButtonDidClick(_ sender: Any) {
        initSDK(nil)
    }
    
    private func initSDK(_ customData: [AnyHashable: Any]?) {
        pt = (ptTextField.text ?? "").isEmpty ? "" : ptTextField.text!
        amount = (amountTextField.text ?? "").isEmpty ? "0.01" : amountTextField.text!
        
        endEdit()
        
        SnapliiSDKManager.defaultService().initAppId(APP_ID, language: lang, personalToken: pt, customData:customData) { [weak self] responseCallback in
            guard let strongSelf = self else {
                return
            }
            strongSelf.getOtp { result, error in
                if let opt = result {
                    responseCallback(opt)
                } else if let error = error {
                    dump(error)
                }
            }
        }
        
        let version = SnapliiSDKManager.defaultService().getVersion()
        print(version)
    }
    
    @IBAction func hasSnapliiCredit(_ sender: Any) {
        endEdit()
        SnapliiSDKManager.defaultService().hasSnapliiCredit { [weak self] success, message in
            guard let strongSelf = self else { return }
            strongSelf.result = message ?? ""
        }
    }
    
    @IBAction func getToApplySnapliiCredit(_ sender: Any) {
        endEdit()
        SnapliiSDKManager.defaultService().initSnapliiCredit(self)  { [weak self] success, message in
            guard let strongSelf = self else { return }
            strongSelf.resultLabel.text = message ?? ""
        }
    }
    
    @IBAction func getOrderNumber(_ sender: Any) {
        resetResultUI()
        
        let url = ""
        
        let interval = NSTimeIntervalSince1970
        let timestamp = String(format: "%zd", interval)
        
        let parameters = [
            "orderAmount": amount,
            "outterOrderNo": timestamp,
            "personalToken": pt
        ]
        
        networkManager.post(url, parameters: parameters, headers: nil) { progress in
            dump(progress)
        } success: { [weak self] task, responseObject in
            guard let strongSelf = self else { return }
            do {
                if let responseData = responseObject as? Data {
                    if let data = try JSONSerialization.jsonObject(with: responseData, options:.mutableContainers) as? [String: Any], let sign = data["sign"] as? String, let outterOrderNo = data["outterOrderNo"] as? String {
                        strongSelf.sign = sign
                        strongSelf.outterOrderNo = outterOrderNo
                        strongSelf.result = String(describing: data)
                    } else {
                        strongSelf.error = String(describing: responseData)
                    }
                } else {
                    strongSelf.error = String(describing: responseObject)
                }
            } catch let error {
                strongSelf.error = String(describing: error)
            }
        } failure: { [weak self] task, error in
            guard let strongSelf = self else { return }
            strongSelf.error = String(describing: error)
        }
    }
    
    @IBAction func payButtonDidClick(_ sender: Any) {
        endEdit()
        resetResultUI()
        
        let url = ""
        
        let interval = Date().timeIntervalSince1970
        let timestamp = String(format: "%f", interval)
        
        let parameters = [
            "orderAmount": amount,
            "outterOrderNo": timestamp,
            "personalToken": pt
        ]
        
        networkManager.post(url, parameters: parameters, headers: nil) { progress in
            dump(progress)
        } success: { [weak self] task, responseObject in
            guard let strongSelf = self else { return }
            do {
                if let responseData = responseObject as? Data {
                    if let data = try JSONSerialization.jsonObject(with: responseData, options:.mutableContainers) as? [String: Any], let sign = data["sign"] as? String, let outterOrderNo = data["outterOrderNo"] as? String {
                        strongSelf.result = String(describing: data)
                        strongSelf.goToPayment(sign, outterOrderNo)
                    } else {
                        strongSelf.error = "Not a Dictionary! \(responseData)"
                    }
                } else {
                    strongSelf.error = "Not data! \(String(describing: responseObject))"
                }
            } catch let error {
                strongSelf.error = "JSONSerialization - \(error)"
            }
        } failure: { [weak self] task, error in
            guard let strongSelf = self else { return }
            strongSelf.error = "Post - \(error)"
        }
    }
    
    @IBAction func hasLogin(_ sender: Any) {
        endEdit()
        let hasLogin = SnapliiSDKManager.defaultService().hasLogin()
        self.resultLabel.text = hasLogin ? "has login" : "not login"
    }
    
    @IBAction func login(_ sender: Any) {
        endEdit()
    }
    
    @IBAction func logout(_ sender: Any) {
        SnapliiSDKManager.defaultService().logout()
    }
    
    
    func resetResultUI() {
        error = ""
        result = ""
    }
    
    func goToPayment(_ sign: String, _ outterOrderNo: String) {
        SnapliiSDKManager.defaultService().payment(sign, orderAmount: amount, outterOrderNo: outterOrderNo, viewController: self) { [weak self] success, message in
            guard let strongSelf = self else { return }
            dump("Payment result: \(message ?? "success")")
            strongSelf.result = message ?? ""
        }
    }
    
    // MARK: 获取OTP
    func getOtp(callback: @escaping (_ result: String?, _ error: String?) -> Void) {
        
    }
    
    lazy var networkManager: AFHTTPSessionManager = {
        let manager = AFHTTPSessionManager(sessionConfiguration: URLSessionConfiguration.default)
        manager.requestSerializer = AFJSONRequestSerializer()
        manager.requestSerializer.setValue("application/json", forHTTPHeaderField: "Content-Type")
        manager.responseSerializer = AFHTTPResponseSerializer()
        manager.responseSerializer.acceptableContentTypes = [
            "application/json", "text/html", "text/json", "text/plain", "text/javascript", "text/xml", "image/*"
        ]
        return manager
    }()
}

extension SDViewController: UIScrollViewDelegate {
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        ptTextField.endEditing(true)
        amountTextField.endEditing(true)
    }
    
    func endEdit() {
        ptTextField.endEditing(true)
        amountTextField.endEditing(true)
    }
}
