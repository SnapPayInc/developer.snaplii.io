//
//  SDAppDelegate.swift
//  SnapliiSDKDemo
//
//  Created by Tony on 2023-07-19.
//

import UIKit

@main
class SDAppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        
        let tab = SNTabController()
        window = UIWindow(frame: UIScreen.main.bounds)
        window?.rootViewController = tab
        window?.makeKeyAndVisible()
        
        return true
    }
    
    
}
